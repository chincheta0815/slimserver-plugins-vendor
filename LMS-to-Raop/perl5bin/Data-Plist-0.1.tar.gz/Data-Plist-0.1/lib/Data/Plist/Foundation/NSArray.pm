package Data::Plist::Foundation::NSArray;

use strict;
use warnings;

use base qw/Data::Plist::Foundation::NSObject/;

1;

