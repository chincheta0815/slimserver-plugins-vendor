package Data::Plist::Foundation::ToDo;

use strict;
use warnings;

use base qw/Data::Plist::Foundation::NSObject/;

1;

