package Data::Plist::Foundation::ToDoAlarms;

use strict;
use warnings;

use base qw/Data::Plist::Foundation::NSObject/;

1;

